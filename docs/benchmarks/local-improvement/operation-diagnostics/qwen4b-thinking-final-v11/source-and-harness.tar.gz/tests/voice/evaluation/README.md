# Local voice evaluation

This is an opt-in measurement suite. It runs real downloaded models and, for
agent/voice flows, controls the real desktop on workspace 98. Do not run CPU
benchmarks concurrently: contention invalidates latency comparisons.

## Corpus and scoring

`utterances.tsv` contains 50 final utterances per language and 10 separate
 development utterances. `corpus.py` adds predetermined critical phrases and
20 deterministic non-speech cases per language. Preparation uses two synthetic
speakers per language, three speeds and clean/quiet/noise conditions. Generated
speech is not evidence about human microphones or natural noisy rooms.

The manifest contains the corpus hash, audio hash, synthetic speaker, speed and
condition for every case. Frozen inputs are verified before recognition.
CER uses Unicode normalization and ignores punctuation/spacing; numeral and
spelling variations still count. Critical phrase accuracy is lexical, not a
full intent judgment. Noise false activations are separate from CER. Missing,
failed and duplicate observations cannot be silently removed.

```sh
LOCAL="$HOME/.local/share/oma/local"
"$LOCAL/venv/bin/python" tests/voice/evaluation/speech.py prepare \
  --output "$HOME/.local/share/oma/evaluation/v1"
"$LOCAL/venv/bin/python" tests/voice/evaluation/speech.py asr --engine whisper \
  --fixtures "$HOME/.local/share/oma/evaluation/v1" --split final --output /tmp/stt-baseline
"$LOCAL/comparison/asr-venv/bin/python" tests/voice/evaluation/speech.py asr --engine qwen \
  --fixtures "$HOME/.local/share/oma/evaluation/v1" --split final --output /tmp/stt-candidate
python3 tests/voice/evaluation/report.py asr /tmp/stt-baseline /tmp/stt-candidate
```

Output directories must not already exist. No downloads or paid inference are
performed. The Qwen comparison environment must already be installed.

## Synthesis

```sh
"$LOCAL/venv/bin/python" tests/voice/evaluation/speech.py tts --split final \
  --worker docs/benchmarks/local-improvement/baseline-local-speech.py --output /tmp/tts-baseline
"$LOCAL/venv/bin/python" tests/voice/evaluation/speech.py tts --split final \
  --worker runtime/local-speech.py --output /tmp/tts-candidate
python3 tests/voice/evaluation/report.py tts /tmp/tts-baseline /tmp/tts-candidate
```

Cold loading is recorded separately. Each language has 20 texts, exact
voices/speed unchanged. First PCM time and estimated first audible sample are
both saved. The latter adds leading silence to availability time; it is not a
hardware microphone measurement. Chunk readiness permits an immediate-playback
underrun simulation; naturalness and acoustic omissions still need listening.
The four-thread baseline is a source snapshot, never reconstructed from results.
`tts-threads.py` is a development-only rotating CPU-thread experiment.

## Agent operations

```sh
python3 tests/voice/evaluation/agent.py --model qwen3.5:4b \
  --split final --repeat 5 --output /tmp/oma-agent-baseline
```

Twenty bilingual tasks use real Pi tools and a disposable SQLite memory/working
folder. Desktop checks inspect actual editor contents, modal state and windows.
This bypasses recognition intentionally, and does not count speech claims as
successful actions. The O.M.A. loopback Ollama server uses installed weights;
the production default is not changed. One server schedules both models, avoiding
GPU contention from two independent resident model servers. The app language is explicitly switched.
Settings, clipboard, microphone and original workspace are restored. Unexpected
named/unsaved user documents are preserved. Test-owned failed text is archived.
Private model reasoning is not exported into the public results.

The separate agent forwards `computerUsing` through the plugin's `computerUse`
IPC and waits for it before desktop commands. Thus the floating face is hidden
during observation/input exactly as in the production pipeline. The installed
plugin must include this bridge; an older build is not a valid test environment.
`stage-plugin.py --backup /tmp/unique-manifest-backup.json` stages the current
checkout as a separate evaluation build, changes only manifest entrypoints,
reloads this plugin, and verifies the actual worker executable path. It refuses
an open panel or an existing backup. Keep the backup to restore the previous
entrypoints. This development build links the checkout's `node_modules`.

Sample runner RSS and model/device VRAM separately while the matrix runs:
`python3 tests/voice/evaluation/memory-sampler.py --pid EVALUATION_PID --output /tmp/memory.jsonl`.
The first sample starts when invoked; missing startup samples are not inferred.

For a harness probe, select `--split dev --repeat 1 --languages ja`.
A selected subset is not a full acceptance run. Individual failures remain in
`results.json`; a later run uses a different output directory.

## End to end

```sh
python3 tests/voice/run.py --providers local --languages ja en \
  --repeat 3 --keep-going --artifacts /tmp/oma-voice-final
```

Ten scenarios produce 30 observations per language. The neighbor scenario owns
an extra terminal window and verifies it survives editor close and goodbye.
English voice files always run with the app set to English. These tests use
synthetic speech through PipeWire, not a physical microphone.

## Actual recognition worker

`worker-asr.py` sends the same fixture WAV samples as 24 kHz signed PCM through
production `local-speech.py`. It uses temporary speech configuration, leaves the
installed default unchanged, and measures the actual scipy resampling and JSON
IPC. It records startup warmups separately and scores every final input.

```sh
python3 tests/voice/evaluation/worker-asr.py --stt whisper-small --split final \
  --fixtures "$HOME/.local/share/oma/evaluation/v1" --output /tmp/stt-worker-baseline
python3 tests/voice/evaluation/worker-asr.py --stt qwen3-asr-1.7b --split final \
  --fixtures "$HOME/.local/share/oma/evaluation/v1" --output /tmp/stt-worker-candidate
```

The optional candidate requires Transformers 5.13 or newer and pre-downloaded
`Qwen/Qwen3-ASR-1.7B-hf` weights in the local Hugging Face cache. It supports 30
languages; other configured languages keep Whisper. Missing models produce an
error rather than silently claiming the candidate ran. Existing installations
without `local/speech.json` retain Whisper Small. A configuration of
`{"stt":"qwen3-asr-1.7b"}` enables the candidate; this evaluation has not changed
the installed configuration. See the [official model card](https://huggingface.co/Qwen/Qwen3-ASR-1.7B-hf).

## Reproduce a selected local pipeline

After staging a compatible build and installing the selected weights, run:

```sh
python3 tests/voice/evaluation/e2e.py --model qwen3.5:4b \
  --thinking low --stt qwen3-asr-1.7b --repeat 3 \
  --output /tmp/oma-selected-pipeline
```

This wrapper saves and temporarily selects `local/agent.json` and
`local/speech.json`, records the environment, runs both app languages, and
restores the previous selections even on failure. For Qwen3.5, `low` enables
thinking; the model supports on/off, not a bounded low-effort budget. The app
must report the requested model before a scenario runs.

`local/agent.json` is an optional O.M.A.-owned selection, for example
`{"model":"qwen3.5:4b","thinkingLevel":"low"}`. It never changes the user's
normal Pi provider or credentials. Without it, the existing 4B/off default
is retained. The optional speech selection is
`{"stt":"qwen3-asr-1.7b"}` in `local/speech.json`; unsupported Qwen languages
continue to use Whisper. Weights and compatible dependencies must already
be installed; these test commands do not download them.

For a complete baseline matrix that is expected to lose disposable drafts,
`agent.py --continue-after-fixture-loss` permits moving to the next isolated
case after recording that exact critical failure. It never continues after
an unrelated-window error. Such losses remain critical failures in the report;
they cannot pass acceptance. By default all critical errors stop the run.
