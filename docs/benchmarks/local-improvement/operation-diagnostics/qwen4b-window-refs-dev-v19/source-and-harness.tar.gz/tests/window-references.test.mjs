import test from 'node:test';
import assert from 'node:assert/strict';
const load=()=>import('../runtime/window-references.mjs');
const windows=[{address:'0xabc123',pid:10,title:'Draft — OmaText',class:'editor',workspace:{id:98},mapped:true},{address:'0xdef456',pid:20,title:'Other app',class:'browser',workspace:{id:98},mapped:true}];
test('short window references resolve only the observed target and expire on refresh',async()=>{
 const {WindowReferences}=await load(),refs=new WindowReferences();
 const observed=refs.observe(windows);
 assert.equal(observed[0].windowId,'w1');assert.equal(observed[0].address,undefined);
 assert.equal(refs.resolve('w2',windows),'0xdef456');
 assert.throws(()=>refs.resolve('0xdef456',windows),/reference|list_windows/i);
 refs.observe(windows);
 assert.throws(()=>refs.resolve('w2',windows),/reference|list_windows/i);
 assert.equal(refs.resolve('w4',windows),'0xdef456');
});
test('reused addresses, hidden windows and moved targets cannot use a stale reference',async()=>{
 const {WindowReferences}=await load();
 for(const patch of [{pid:30},{title:'A different document'}, {workspace:{id:2}},{hidden:true},{mapped:false}]){
  const refs=new WindowReferences();refs.observe(windows);
  assert.throws(()=>refs.resolve('w1',[{...windows[0],...patch},windows[1]]),/changed|unavailable/i);
 }
});
