#!/usr/bin/env python3
"""Copy the dirty checkout into a separate reproducible evaluation source root."""
import argparse,hashlib,json,shutil
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
a=p.parse_args();root=Path(__file__).resolve().parents[3];a.output=a.output.resolve()
a.output.mkdir(parents=True,exist_ok=False)
for name in ['runtime','skills','tests','native','assets','scripts']:
 if (root/name).exists():shutil.copytree(root/name,a.output/name,ignore=shutil.ignore_patterns('__pycache__'))
for pattern in ['*.qml','*.json','.npmrc','*.md','docs/*.md']:
 for path in root.glob(pattern):
  if path.is_file():
   target=a.output/path.relative_to(root);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
(a.output/'node_modules').symlink_to(root/'node_modules',target_is_directory=True)
hashes={str(path.relative_to(a.output)):hashlib.sha256(path.read_bytes()).hexdigest() for path in a.output.rglob('*') if path.is_file() and not path.is_symlink()}
(a.output/'snapshot-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
print(json.dumps({'source':str(a.output),'files':len(hashes),'dependencies':'node_modules symlink; package-lock.json is recorded'}))
