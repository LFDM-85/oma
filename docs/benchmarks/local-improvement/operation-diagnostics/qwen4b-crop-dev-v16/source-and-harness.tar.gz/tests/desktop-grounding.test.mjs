import test from 'node:test';
import assert from 'node:assert/strict';
import {targetClickTool,parseGroundingPoint,locateDesktopTarget} from '../runtime/desktop-grounding.mjs';
import {desktopTools} from '../runtime/desktop.mjs';
test('target clicks request a visible target instead of conversational coordinates',()=>{
 const source=desktopTools.find(t=>t.name==='desktop_click');const tool=targetClickTool(source);
 assert.deepEqual(tool.inputSchema.required,['frameId','target','button']);
 assert.equal(tool.inputSchema.properties.x,undefined);assert.ok(source.inputSchema.properties.x);
});
test('grounding accepts one bounded point and refuses absent or ambiguous targets',()=>{
 assert.deepEqual(parseGroundingPoint('```json\n[{"point_2d":[463,539],"label":"Don’t Save"}]\n```'),{x:463,y:539});
 assert.deepEqual(parseGroundingPoint('{"x":40,"y":60}'),{x:40,y:60});
 for(const text of ['[]','null','[{"point_2d":[2,3]},{"point_2d":[4,5]}]','{"x":1001,"y":3}','{"x":"40","y":60}','I cannot see it'])assert.throws(()=>parseGroundingPoint(text));
});
test('grounding has only the observed image and target, no conversation or tools',async()=>{
 const frame={id:'f',time:Date.now(),image:{mimeType:'image/png',data:'eA=='}};
 const signal=new AbortController().signal;
 let calls=0;
 const complete=async(context,options)=>{
  calls++;assert.equal(context.messages.length,1);assert.equal(context.tools,undefined);
  assert.equal(options.reasoning,'off');assert.equal(options.signal,signal);
  assert.match(context.messages[0].content[0].text,/Don't Save/);
  return {stopReason:'stop',content:[{type:'text',text:'{"x":463,"y":539}'}]};
 };
 const args={frameId:'f',target:"Don't Save button",button:'left'};
 assert.deepEqual(await locateDesktopTarget({frame,args,complete,signal}),{frameId:'f',x:463,y:539,button:'left'});
 await assert.rejects(()=>locateDesktopTarget({frame,args:{...args,frameId:'old'},complete,signal}),/fresh screenshot/);
 assert.equal(calls,1);
});

test('a zoomed refinement maps its point back to the original screenshot',async()=>{
 const frame={id:'f',time:Date.now(),width:1440,height:810,image:{mimeType:'image/png',data:'original'}};
 const args={frameId:'f',target:"Don't Save button",button:'left'};
 let calls=0,region;
 const complete=async(context)=>{
  calls++;
  assert.equal(context.messages[0].content[1].data,calls===1?'original':'zoom');
  return {stopReason:'stop',content:[{type:'text',text:JSON.stringify(calls===1?{x:500,y:500}:{x:250,y:500})}]};
 };
 const result=await locateDesktopTarget({frame,args,complete,crop:async r=>{region=r;return {mimeType:'image/png',data:'zoom'}}});
 assert.equal(calls,2);assert.deepEqual(region,{x:528,y:277,width:384,height:256});
 assert.equal(result.y,500);assert.ok(Math.abs(result.x-433.3333333333)<.000001);
});
test('ambiguous refinement refuses the click instead of using the coarse guess',async()=>{
 let calls=0;
 const frame={id:'f',time:Date.now(),width:1440,height:810,image:{mimeType:'image/png',data:'original'}};
 await assert.rejects(()=>locateDesktopTarget({frame,args:{frameId:'f',target:'Save',button:'left'},crop:async()=>frame.image,complete:async()=>({stopReason:'stop',content:[{type:'text',text:++calls===1?'{"x":999,"y":1}':'null'}]})}));
 assert.equal(calls,2);
});
