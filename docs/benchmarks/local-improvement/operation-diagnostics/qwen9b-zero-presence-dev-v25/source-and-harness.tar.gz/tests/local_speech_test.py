import importlib.util
import pathlib
import unittest


class LocalSpeechTest(unittest.TestCase):
    def test_tts_thread_budget_uses_available_cpus_without_oversubscription(self):
        path = pathlib.Path(__file__).parents[1] / 'runtime/local-speech.py'
        spec = importlib.util.spec_from_file_location('local_speech', path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        self.assertTrue(hasattr(module, 'tts_thread_count'), 'TTS CPU budget is missing')
        self.assertEqual(module.tts_thread_count(32), 8)
        self.assertEqual(module.tts_thread_count(2), 2)
        self.assertEqual(module.tts_thread_count(1), 1)

    def test_trimming_removes_only_digital_silence_and_keeps_onset_padding(self):
        path = pathlib.Path(__file__).parents[1] / 'runtime/local-speech.py'
        spec = importlib.util.spec_from_file_location('local_speech', path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        self.assertTrue(hasattr(module, 'trim_start_padding'), 'Leading silence trimming is missing')
        quiet = bytes(12000)
        speech = b'\x01\x00\xff\xff' + bytes(2000)
        self.assertEqual(module.trim_start_padding(quiet + speech), bytes(960) + speech)
        self.assertEqual(module.trim_start_padding(speech), speech)
        self.assertEqual(module.trim_start_padding(quiet), quiet)

    def test_optional_asr_selection_preserves_unsupported_languages(self):
        import tempfile,json
        path = pathlib.Path(__file__).parents[1] / 'runtime/local-speech.py'
        spec = importlib.util.spec_from_file_location('local_speech', path)
        module = importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        with tempfile.TemporaryDirectory() as directory:
            self.assertEqual(module.Engines(directory).asr_backend('ja'), 'whisper-small')
            (pathlib.Path(directory)/'speech.json').write_text(json.dumps({'stt':'qwen3-asr-1.7b'}))
            engine=module.Engines(directory)
            for language in ('ja','en','de','ar'):
                self.assertEqual(engine.asr_backend(language), 'qwen3-asr-1.7b')
            self.assertEqual(engine.asr_backend('uk'), 'whisper-small')
            (pathlib.Path(directory)/'speech.json').write_text(json.dumps({'stt':'misspelled-model'}))
            with self.assertRaises(ValueError):module.Engines(directory)

    def test_voice_language_selection_does_not_silently_use_english(self):
        path = pathlib.Path(__file__).parents[1] / 'runtime/local-speech.py'
        self.assertTrue(path.exists(), 'Local speech worker is missing')
        spec = importlib.util.spec_from_file_location('local_speech', path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        self.assertEqual(module.voice_for('ja'), ('j', 'jm_kumo'))
        self.assertEqual(module.voice_for('en'), ('a', 'am_michael'))
        self.assertEqual(module.voice_for('fr'), ('f', 'ff_siwis'))
        self.assertIsNone(module.voice_for('de'))


if __name__ == '__main__':
    unittest.main()
