import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,readFileSync,writeFileSync,mkdirSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {Memory} from '../runtime/memory.mjs';
const pi=await import('../runtime/pi.mjs').catch(()=>({}));
function fixture(t){const home=mkdtempSync(join(tmpdir(),'oma-pi-'));const memory=new Memory(join(home,'memory.sqlite'));t.after(()=>{memory.close();rmSync(home,{recursive:true,force:true});});return {home,memory};}
test('Pi resources include bundled skills and the installed Omarchy skill, but no ambient extensions',async t=>{
 assert.equal(typeof pi.createResources,'function','Pi resource loader missing');
 const {home,memory}=fixture(t),skill=join(home,'omarchy','SKILL.md');mkdirSync(join(home,'omarchy'));writeFileSync(skill,'---\nname: omarchy\ndescription: Desktop settings\n---\nUse the supported Omarchy CLI.');
 const loader=await pi.createResources({home,cwd:home,memory,locale:'ja-JP',omarchySkill:skill});
 assert.deepEqual(loader.getSkills().skills.map(s=>s.name).sort(),['oma','oma-camera','omarchy']);
 assert.match(loader.getSystemPrompt(),/Japanese/);assert.match(loader.getSystemPrompt(),/Use the supported Omarchy CLI/);
 assert.equal(loader.getExtensions().extensions.length,0);
});
test('memory tools persist facts and exact URLs while confirmation denial never grants permission',async t=>{
 assert.equal(typeof pi.PiAgent,'function','Pi agent missing');const {home,memory}=fixture(t),patches=[];
 const agent=new pi.PiAgent({home,cwd:home,memory,emit:p=>patches.push(p)});
 const tools=agent.tools();const call=(name,args)=>tools.find(t=>t.name===name).execute(name,args,new AbortController().signal);
 await call('remember',{key:'favorite',value:'fictional amber'});
 assert.match(JSON.stringify(await call('search_memory',{query:'amber'})),/fictional amber/);
 const denied=call('confirm_action',{description:'Publish the draft'});
 const approval=patches.find(p=>p.approval).approval;agent.approve(approval.id,false);
 assert.equal(JSON.parse((await denied).content[0].text).approved,false);
});
test('forget purges O.M.A. Pi sessions and facts without deleting unrelated Pi data',async t=>{
 assert.equal(typeof pi.PiAgent,'function','Pi agent missing');const {home,memory}=fixture(t);
 const own=join(home,'pi');mkdirSync(join(own,'sessions'),{recursive:true});writeFileSync(join(own,'sessions','old.jsonl'),'private orange');
 writeFileSync(join(home,'unrelated.jsonl'),'keep');memory.remember('favorite','private orange');
 const agent=new pi.PiAgent({home:own,cwd:home,memory,emit(){}});
 await agent.tools().find(t=>t.name==='forget').execute('forget',{query:'orange'},new AbortController().signal);
 await agent.resetForgottenSession();
 assert.equal(memory.search('orange').length,0);assert.equal(readFileSync(join(home,'unrelated.jsonl'),'utf8'),'keep');
 assert.equal((await import('node:fs')).existsSync(join(own,'sessions','old.jsonl')),false);
});
test('Pi settings alone select the model; old O.M.A. overrides and speech key are ignored',async t=>{
 const {home,memory}=fixture(t);const config=join(home,'config');mkdirSync(config);
 writeFileSync(join(config,'settings.json'),JSON.stringify({defaultProvider:'fixture',defaultModel:'chosen'}));
 memory.set('piProvider','old');memory.set('piModel','old');let injected=false;
 const model={provider:'fixture',id:'chosen'};
 const modelRuntime={getAvailable:async()=>[model],getModel:(p,m)=>p===model.provider&&m===model.id?model:undefined,setRuntimeApiKey:async()=>{injected=true;}};
 const agent=new pi.PiAgent({home,cwd:home,memory,key:'speech-only',emit(){},modelRuntime,env:{PI_CODING_AGENT_DIR:config,OMA_PI_PROVIDER:'old',OMA_PI_MODEL:'old'}});
 assert.equal(await agent.status(),true);assert.equal(agent.provider,'fixture');assert.equal(agent.modelId,'chosen');assert.equal(injected,false);
});
test('missing Pi defaults require setup without choosing an arbitrary available model',async t=>{
 const {home,memory}=fixture(t);const patches=[];
 const agent=new pi.PiAgent({home,cwd:home,memory,emit:p=>patches.push(p),env:{PI_CODING_AGENT_DIR:home},modelRuntime:{getAvailable:async()=>[{provider:'openai',id:'gpt-4.1'}],getModel:()=>undefined}});
 assert.equal(await agent.status(),false);assert.equal(patches.at(-1).modelProvider,'');assert.equal(patches.at(-1).modelName,'');
 await assert.rejects(()=>agent.start(),/Pi.*default model/);
});
test('Pi exposes the same mini and normal presentation tool',async t=>{
 const {home,memory}=fixture(t),patches=[];
 const agent=new pi.PiAgent({home,cwd:home,memory,emit:p=>patches.push(p)});
 const tool=agent.tools().find(t=>t.name==='set_view_mode');assert.ok(tool);
 for(const mode of ['mini','normal'])await tool.execute('mode',{mode},new AbortController().signal);
 assert.deepEqual(patches,[{viewMode:'mini'},{viewMode:'normal'}]);
 await assert.rejects(()=>tool.execute('mode',{mode:'other'},new AbortController().signal),/Invalid/);
});

test('a length-limited model reply does not mark the operation completed',async t=>{
 const {home,memory}=fixture(t);
 const agent=new pi.PiAgent({home,cwd:home,memory,emit(){}});
 agent.session={subscribe:()=>()=>{},prompt:async()=>{},messages:[{role:'assistant',content:[],stopReason:'length'}]};
 await assert.rejects(()=>agent.run('Open the editor'),/limit|truncated/i);
 assert.notEqual(JSON.parse(memory.get('taskCheckpoint')).status,'completed');
});

test('Pi executes the same literal command arguments as the shared OMA skill',async t=>{
 const {home,memory}=fixture(t);
 const agent=new pi.PiAgent({home,cwd:home,memory,emit(){}});
 const tool=agent.tools().find(t=>t.name==='run_command');assert.ok(tool);
 const literal='spaces; $(not-a-command)';
 const result=await tool.execute('command',{command:process.execPath,args:['-e','process.stdout.write(process.argv[1])',literal]},new AbortController().signal);
 assert.equal(JSON.parse(result.content[0].text).stdout,literal);
 const controller=new AbortController();controller.abort();
 await assert.rejects(()=>tool.execute('command',{command:process.execPath,args:['-e','throw Error()']},controller.signal),/abort/i);
});

test('Pi respects the configured reasoning level for model comparisons',async t=>{
 const {home,memory}=fixture(t);
 writeFileSync(join(home,'settings.json'),JSON.stringify({defaultProvider:'oma-local',defaultModel:'qwen3.5:9b',defaultThinkingLevel:'low'}));
 const agent=new pi.PiAgent({home,cwd:home,memory,emit(){},env:{PI_CODING_AGENT_DIR:home},modelRuntime:{}});
 await agent.configure();assert.equal(agent.thinkingLevel,'low');
});

test('ending a conversation permits a final reply but no further tool actions',async t=>{
 const {home,memory}=fixture(t);let dismissed=0;const updates=[];
 const agent=new pi.PiAgent({home,cwd:home,memory,emit(){}});
 agent.onDismiss=()=>dismissed++;
 const active=['read','end_conversation'];
 agent.session={getActiveToolNames:()=>active,setActiveToolsByName:names=>updates.push(names),subscribe:()=>()=>{},messages:[{role:'assistant',stopReason:'stop'}],prompt:async()=>{
  const end=agent.tools().find(tool=>tool.name==='end_conversation');
  await end.execute('end',{},new AbortController().signal);
  await end.execute('duplicate-end',{},new AbortController().signal);
  assert.deepEqual(updates,[[]]);
 }};
 await agent.run('Please end this conversation.');
 assert.equal(dismissed,1);
 assert.deepEqual(updates,[[],active],'An interrupted closure must not disable later conversation tools');
});

test('three identical failed tool actions stop with an error rather than reporting completion',async t=>{
 const {home,memory}=fixture(t);let listener,aborts=0;
 const agent=new pi.PiAgent({home,cwd:home,memory,emit(){}});agent.provider='oma-local';
 agent.session={subscribe:fn=>{listener=fn;return()=>{};},abort:async()=>{aborts++;},messages:[{role:'assistant',stopReason:'stop'}],prompt:async()=>{
  for(let n=0;n<3;n++){
   listener({type:'tool_execution_start',toolCallId:String(n),toolName:'desktop_type',args:{frameId:'stale',text:'Note'}});
   listener({type:'tool_execution_end',toolCallId:String(n),toolName:'desktop_type',isError:true,result:{}});
  }
  await Promise.resolve();
 }};
 await assert.rejects(()=>agent.run('Type a note'),/same tool action failed three times/i);
 assert.equal(aborts,1);
 assert.notEqual(JSON.parse(memory.get('taskCheckpoint')).status,'completed');
});

test('successful or corrected tool actions reset the repeated-error guard',async t=>{
 const {home,memory}=fixture(t);let listener;
 const agent=new pi.PiAgent({home,cwd:home,memory,emit(){}});agent.provider='oma-local';
 agent.session={subscribe:fn=>{listener=fn;return()=>{};},abort:async()=>assert.fail('Recovery must remain possible'),messages:[{role:'assistant',stopReason:'stop'}],prompt:async()=>{
  for(const [n,[frameId,isError]] of [['old',true],['old',true],['new',true],['new',true],['new',false],['new',true],['new',true]].entries()){
   listener({type:'tool_execution_start',toolCallId:String(n),toolName:'desktop_type',args:{frameId,text:'Note'}});
   listener({type:'tool_execution_end',toolCallId:String(n),toolName:'desktop_type',isError,result:{}});
  }
  await Promise.resolve();
 }};
 await agent.run('Type a note');
 assert.equal(JSON.parse(memory.get('taskCheckpoint')).status,'completed');
});

test('Pi exposes literal append without rebuilding existing file contents',async t=>{
 const {home,memory}=fixture(t);writeFileSync(join(home,'note.txt'),'Keep. ');
 const agent=new pi.PiAgent({home,cwd:home,memory,emit(){}});
 const tool=agent.tools().find(tool=>tool.name==='append_text_file');assert.ok(tool);
 const result=await tool.execute('append',{path:'note.txt',text:'追記'},new AbortController().signal);
 assert.equal(readFileSync(join(home,'note.txt'),'utf8'),'Keep. 追記');
 assert.equal(JSON.parse(result.content[0].text).bytesAppended,6);
});

test('cancel uses a recorded pending target and refuses ambiguity',async t=>{
 const {home,memory}=fixture(t);const agent=new pi.PiAgent({home,cwd:home,memory,emit(){}});
 const tools=agent.tools(),close=tools.find(x=>x.name==='close_application_window'),cancel=tools.find(x=>x.name==='cancel_application_close');assert.ok(cancel);
 const signal=new AbortController().signal;
 await assert.rejects(()=>cancel.execute('none',{},signal),/single|pending/i);
 let bClosed=false;
 agent.companion.closeTarget=async address=>({closed:address==='0xb'&&bClosed,requiresAttention:!(address==='0xb'&&bClosed)});
 await close.execute('a',{address:'0xa'},signal);await close.execute('b',{address:'0xb'},signal);
 await assert.rejects(()=>cancel.execute('ambiguous',{},signal),/single|ambiguous/i);
 bClosed=true;await close.execute('b-done',{address:'0xb'},signal);
 agent.desktop={check(){},async json(){return [{address:'0xa',title:'Untitled — OmaText',mapped:true,pid:7,workspace:{id:98}}]},async command(){return Buffer.from(JSON.stringify({opened:true,busy:false,editor:{modalOpen:false}}))}};
 const result=JSON.parse((await cancel.execute('cancel-a',{},signal)).content[0].text);
 assert.equal(result.address,'0xa');assert.equal(result.cancelled,true);
 await assert.rejects(()=>cancel.execute('duplicate',{},signal),/single|pending/i);
});
