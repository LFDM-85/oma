#!/usr/bin/env python3
"""Run the real local voice pipeline with recorded, temporarily selected models."""
import argparse,json,os,subprocess,sys
from pathlib import Path

from environment import environment

ROOT=Path(__file__).resolve().parents[3]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--model',required=True,choices=['qwen3.5:4b','qwen3.5:4b-q8_0','qwen3.5:9b','gemma4:e2b'])
p.add_argument('--stt',required=True,choices=['whisper-small','qwen3-asr-1.7b'])
p.add_argument('--thinking',choices=['off','low','medium','high'],default='off')
p.add_argument('--temperature',type=float)
p.add_argument('--top-p',type=float)
p.add_argument('--presence-penalty',type=float)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--repeat',type=int,default=3)
p.add_argument('--languages',nargs='+',choices=['ja','en'],default=['ja','en'])
p.add_argument('--cases',nargs='+')
a=p.parse_args()
a.output=a.output.resolve();a.output.mkdir(parents=True,exist_ok=False)
(a.output/'environment.json').write_text(json.dumps(environment(a.model),indent=2)+'\n')
state=json.loads(subprocess.check_output(['omarchy-shell','io.github.komagata.oma','status']))
assert not state['panelOpened'],'Close O.M.A. before selecting evaluation models'
local=Path(os.environ.get('OMA_DATA_DIR',str(Path(os.environ.get('XDG_DATA_HOME',str(Path.home()/'.local/share')))/'oma')))/'local'
updates={'agent.json':{'model':a.model,'thinkingLevel':a.thinking},'speech.json':{'stt':a.stt}}
sampling={k:v for k,v in {'temperature':a.temperature,'top_p':a.top_p,'presence_penalty':a.presence_penalty}.items() if v is not None}
if sampling:updates['agent.json']['sampling']=sampling
backups={name:(local/name).read_bytes() if (local/name).exists() else None for name in updates}
(a.output/'configuration.json').write_text(json.dumps({'model':a.model,'stt':a.stt,'thinking':a.thinking,'sampling_overrides':sampling,'repeat':a.repeat,'languages':a.languages,'cases':a.cases,'local_directory':str(local)},indent=2)+'\n')
for name,data in backups.items():
 if data is not None:(a.output/('original-'+name)).write_bytes(data)
command=[sys.executable,str(ROOT/'tests/voice/run.py'),'--providers','local','--languages',*a.languages,'--repeat',str(a.repeat),'--keep-going','--artifacts',str(a.output/'trials')]
if a.cases:command+=['--cases',*a.cases]
try:
 for name,value in updates.items():(local/name).write_text(json.dumps(value)+'\n')
 with (a.output/'runner.log').open('w') as log:
  result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'OMA_EVALUATION_MODEL':a.model})
finally:
 for name,data in backups.items():
  if data is None:(local/name).unlink(missing_ok=True)
  else:(local/name).write_bytes(data)
sys.exit(result.returncode)
