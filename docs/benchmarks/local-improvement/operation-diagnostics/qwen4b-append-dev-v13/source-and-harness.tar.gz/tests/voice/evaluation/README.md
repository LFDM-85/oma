# Local voice evaluation

This is an opt-in measurement suite. It runs real downloaded models and, for
agent/voice flows, controls the real desktop on workspace 98. Do not run CPU
benchmarks concurrently: contention invalidates latency comparisons.

## Corpus and scoring

`utterances.tsv` contains 50 final utterances per language and 10 separate
 development utterances. `corpus.py` adds predetermined critical phrases and
20 deterministic non-speech cases per language. Preparation uses two synthetic
speakers per language, three speeds and clean/quiet/noise conditions. Generated
speech is not evidence about human microphones or natural noisy rooms.

The manifest contains the corpus hash, audio hash, synthetic speaker, speed and
condition for every case. Frozen inputs are verified before recognition.
CER uses Unicode normalization and ignores punctuation/spacing; numeral and
spelling variations still count. Critical phrase accuracy is lexical, not a
full intent judgment. Noise false activations are separate from CER. Missing,
failed and duplicate observations cannot be silently removed.

```sh
LOCAL="$HOME/.local/share/oma/local"
"$LOCAL/venv/bin/python" tests/voice/evaluation/speech.py prepare \
  --output "$HOME/.local/share/oma/evaluation/v1"
"$LOCAL/venv/bin/python" tests/voice/evaluation/speech.py asr --engine whisper \
  --fixtures "$HOME/.local/share/oma/evaluation/v1" --split final --output /tmp/stt-baseline
"$LOCAL/comparison/asr-venv/bin/python" tests/voice/evaluation/speech.py asr --engine qwen \
  --fixtures "$HOME/.local/share/oma/evaluation/v1" --split final --output /tmp/stt-candidate
python3 tests/voice/evaluation/report.py asr /tmp/stt-baseline /tmp/stt-candidate
```

Output directories must not already exist. No downloads or paid inference are
performed. The Qwen comparison environment must already be installed.

## Synthesis

```sh
"$LOCAL/venv/bin/python" tests/voice/evaluation/speech.py tts --split final \
  --worker docs/benchmarks/local-improvement/baseline-local-speech.py --output /tmp/tts-baseline
"$LOCAL/venv/bin/python" tests/voice/evaluation/speech.py tts --split final \
  --worker runtime/local-speech.py --output /tmp/tts-candidate
python3 tests/voice/evaluation/report.py tts /tmp/tts-baseline /tmp/tts-candidate
```

Cold loading is recorded separately. Each language has 20 texts, exact
voices/speed unchanged. First PCM time and estimated first audible sample are
both saved. The latter adds leading silence to availability time; it is not a
hardware microphone measurement. Chunk readiness permits an immediate-playback
underrun simulation; naturalness and acoustic omissions still need listening.
The four-thread baseline is a source snapshot, never reconstructed from results.
`tts-threads.py` is a development-only rotating CPU-thread experiment.

## Agent operations

```sh
python3 tests/voice/evaluation/agent.py --model qwen3.5:4b \
  --split final --repeat 5 --output /tmp/oma-agent-baseline
```

Twenty bilingual tasks use real Pi tools and a disposable SQLite memory/working
folder. Desktop checks inspect actual editor contents, modal state and windows.
This bypasses recognition intentionally, and does not count speech claims as
successful actions. The O.M.A. loopback Ollama server uses installed weights;
the production default is not changed. One server schedules both models, avoiding
GPU contention from two independent resident model servers. The app language is explicitly switched.
Settings, clipboard, microphone and original workspace are restored. Unexpected
named/unsaved user documents are preserved. Test-owned failed text is archived.
Private model reasoning is not exported into the public results.

The separate agent forwards `computerUsing` through the plugin's `computerUse`
IPC and waits for it before desktop commands. Thus the floating face is hidden
during observation/input exactly as in the production pipeline. The installed
plugin must include this bridge; an older build is not a valid test environment.
`stage-plugin.py --backup /tmp/unique-manifest-backup.json` stages the current
checkout as a separate evaluation build, changes only manifest entrypoints,
reloads this plugin, and verifies the actual worker executable path. It refuses
an open panel or an existing backup. Keep the backup to restore the previous
entrypoints. This development build links the checkout's `node_modules`.

Sample runner RSS and model/device VRAM separately while the matrix runs:
`python3 tests/voice/evaluation/memory-sampler.py --pid EVALUATION_PID --output /tmp/memory.jsonl`.
The first sample starts when invoked; missing startup samples are not inferred.

For a harness probe, select `--split dev --repeat 1 --languages ja`.
A selected subset is not a full acceptance run. Individual failures remain in
`results.json`; a later run uses a different output directory.

## End to end

```sh
python3 tests/voice/run.py --providers local --languages ja en \
  --repeat 3 --keep-going --artifacts /tmp/oma-voice-final
```

Ten scenarios produce 30 observations per language. The neighbor scenario owns
an extra terminal window and verifies it survives editor close and goodbye.
English voice files always run with the app set to English. These tests use
synthetic speech through PipeWire, not a physical microphone.

## Actual recognition worker

`worker-asr.py` sends the same fixture WAV samples as 24 kHz signed PCM through
production `local-speech.py`. It uses temporary speech configuration, leaves the
installed default unchanged, and measures the actual scipy resampling and JSON
IPC. It records startup warmups separately and scores every final input.

```sh
python3 tests/voice/evaluation/worker-asr.py --stt whisper-small --split final \
  --fixtures "$HOME/.local/share/oma/evaluation/v1" --output /tmp/stt-worker-baseline
python3 tests/voice/evaluation/worker-asr.py --stt qwen3-asr-1.7b --split final \
  --fixtures "$HOME/.local/share/oma/evaluation/v1" --output /tmp/stt-worker-candidate
```

The optional candidate requires Transformers 5.13 or newer and pre-downloaded
`Qwen/Qwen3-ASR-1.7B-hf` weights in the local Hugging Face cache. It supports 30
languages; other configured languages keep Whisper. Missing models produce an
error rather than silently claiming the candidate ran. Existing installations
without `local/speech.json` retain Whisper Small. A configuration of
`{"stt":"qwen3-asr-1.7b"}` enables the candidate; this evaluation has not changed
the installed configuration. See the [official model card](https://huggingface.co/Qwen/Qwen3-ASR-1.7B-hf).

## Reproduce a selected local pipeline

After staging a compatible build and installing the selected weights, run:

```sh
python3 tests/voice/evaluation/e2e.py --model qwen3.5:4b \
  --thinking low --stt qwen3-asr-1.7b --repeat 3 \
  --output /tmp/oma-selected-pipeline
```

This wrapper saves and temporarily selects `local/agent.json` and
`local/speech.json`, records the environment, runs both app languages, and
restores the previous selections even on failure. For Qwen3.5, `low` enables
thinking; the model supports on/off, not a bounded low-effort budget. The app
must report the requested model before a scenario runs.

`local/agent.json` is an optional O.M.A.-owned selection, for example
`{"model":"qwen3.5:4b","thinkingLevel":"low"}`. It never changes the user's
normal Pi provider or credentials. Without it, the existing 4B/off default
is retained. The optional speech selection is
`{"stt":"qwen3-asr-1.7b"}` in `local/speech.json`; unsupported Qwen languages
continue to use Whisper. Weights and compatible dependencies must already
be installed; these test commands do not download them.

For a complete baseline matrix that is expected to lose disposable drafts,
`agent.py --continue-after-fixture-loss` permits moving to the next isolated
case after recording that exact critical failure. It never continues after
an unrelated-window error. Such losses remain critical failures in the report;
they cannot pass acceptance. By default all critical errors stop the run.

Optional Qwen ASR installation/selection is reproducible through
`scripts/setup-local --stt qwen3-asr-1.7b`. This downloads the pinned Qwen model
revision and installs Transformers 5.17.0. It preserves an existing speech choice
when no option is given. `--stt whisper-small` selects the smaller recognizer.
Qwen 1.7B used about 12 GiB worker RSS on this machine; it is not a low-memory
replacement. Run setup before collecting a paired comparison, never midway
through a benchmark. The evaluation wrappers themselves do not install packages.

### Read-only editor inspection (optional evaluation instrumentation)

Clipboard verification can fail when Qt activation lags behind compositor focus.
For repeatable native-buffer checks, stage a copied OmaText build while both apps
are closed, before starting either baseline or candidate:

```sh
python3 tests/voice/evaluation/stage-editor-inspection.py --backup /tmp/omatext-original-manifest.json
export OMA_EVALUATION_EDITOR_INSPECTION=1
```

This adds only `inspectEvaluationDocument`, returning the actual document buffer.
It does not insert text, dismiss dialogs, change file IO, or give the model an
expected answer. GUI actions still use the real application. The environment
snapshot records the inspection method, entrypoint and EditorBase hash. Use the
same method for both sides of a comparison. Earlier clipboard failures remain
failures; they are not retroactively rescored. Restore the backed-up manifest
with both applications closed, then disable/rescan/enable OmaText.

Local sampling comparison flags are `--temperature`, `--top-p`, and
`--presence-penalty` for `agent.py` and `e2e.py`. Omitted values retain existing
behavior; explicit overrides and all failures are saved in the run configuration.

### Playback capture, readback and blind listening

After producing the paired `/tmp/tts-baseline` and `/tmp/tts-candidate` WAVs:

```sh
node tests/voice/evaluation/playback.mjs \
  docs/benchmarks/local-improvement/baseline-local-speech.py \
  runtime/local-speech.py /tmp/tts-playback
"$LOCAL/venv/bin/python" tests/voice/evaluation/capture-check.py \
  /tmp/tts-playback /tmp/tts-baseline /tmp/tts-candidate --output /tmp/tts-capture-check.jsonl
"$LOCAL/venv/bin/python" tests/voice/evaluation/readback.py \
  /tmp/tts-baseline /tmp/tts-candidate --output /tmp/tts-readback.jsonl
python3 tests/voice/evaluation/preview.py \
  /tmp/tts-baseline /tmp/tts-candidate --output /tmp/tts-listening
python3 -m http.server 35673 --bind 127.0.0.1 --directory /tmp/tts-listening
```

The readback command requires the installed Whisper Turbo comparison weights.
Playback uses a dedicated null sink and records its monitor; it does not route
samples to the physical speakers. Open the listening page separately for human
ratings. Generation RTF is reported separately by `report.py tts`; trimming
silence can reduce output duration, so a faster onset alone does not imply a
lower generation-time/audio-duration ratio.

### Retained operation baseline source

The original operation implementation is retained even though the working tree
already contained uncommitted work when this goal began:

```sh
mkdir /tmp/oma-operation-baseline-source
tar -xzf docs/benchmarks/local-improvement/baseline-agent-source.tar.gz \
  -C /tmp/oma-operation-baseline-source
ln -s "$PWD/node_modules" /tmp/oma-operation-baseline-source/node_modules
python3 tests/voice/evaluation/agent.py --model qwen3.5:4b --thinking off \
  --agent-module /tmp/oma-operation-baseline-source/runtime/pi.mjs \
  --split final --repeat 5 --continue-after-fixture-loss \
  --output /tmp/oma-operation-baseline-final
```

Use the same installed UI and editor instrumentation for baseline and candidate.
The archive has source hashes beside it. `evaluation-package-lock.json` records
the Node dependencies shared by the measurements; it is evidence, not a request
to overwrite the project's current lockfile. Baseline thinking is off and local
sampling is the original temperature 0.2 with the server's remaining defaults.

Summarize the memory log with
`python3 tests/voice/evaluation/memory-report.py /tmp/memory.jsonl`.
RAM RSS, server-estimated model allocations and whole-device GPU residency are
kept separate. Missing samples and unsampled startup cannot be reconstructed.
