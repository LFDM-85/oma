import test from 'node:test';import assert from 'node:assert/strict';
import {FarewellIntent,directFarewell} from '../runtime/farewell-intent.mjs';
test('only whole direct farewells match',()=>{
 for(const text of ['じゃいいや、バイバイ','バイバイ','ありがとうございました、バイバイ','ありがとうばいばーい','Bye!'])assert.ok(directFarewell(text),text);
 for(const text of ['バイバイって英語で何？','「バイバイ」','終了しないで','ブラウザを終了して'])assert.equal(directFarewell(text),false,text);
});
test('waits for transcript stability, cancels extended phrases and closes once',()=>{
 let calls=0;const f=new FarewellIntent(()=>calls++);
 f.input('こんにちは\nバイバイ',0);f.tick(799);assert.equal(calls,0);
 f.input('こんにちは\nバイバイってどういう意味',800);f.tick(1800);assert.equal(calls,0);
 f.input('こんにちは\nバイバイ',2000);f.tick(2800);f.tick(4000);assert.equal(calls,1);
 f.reset();f.input('バイバイ',5000);f.reset();f.tick(6000);assert.equal(calls,1);
});
