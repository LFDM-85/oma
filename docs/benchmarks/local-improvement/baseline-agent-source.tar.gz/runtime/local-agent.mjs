import {mkdirSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
// O.M.A. owns this directory. Never replace the user's ~/.pi/agent settings.
export function localAgentConfig(data){
 const config=join(data,'local','pi-config');mkdirSync(config,{recursive:true,mode:0o700});
 const write=(name,value)=>writeFileSync(join(config,name),JSON.stringify(value,null,2)+'\n',{mode:0o600});
 write('settings.json',{defaultProvider:'oma-local',defaultModel:'qwen3.5:4b'});
 write('models.json',{providers:{'oma-local':{
  baseUrl:'http://127.0.0.1:11435/v1',api:'openai-completions',apiKey:'local',
  models:[{id:'qwen3.5:4b',name:'Qwen3.5 4B · Local',reasoning:true,
   thinkingLevelMap:{off:'none'},input:['text','image'],contextWindow:32768,maxTokens:2048,
   cost:{input:0,output:0,cacheRead:0,cacheWrite:0},
   compat:{supportsStore:false,supportsDeveloperRole:false,supportsReasoningEffort:true,maxTokensField:'max_tokens'}}]
 }}});
 return config;
}
