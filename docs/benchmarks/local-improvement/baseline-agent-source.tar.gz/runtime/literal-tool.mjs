// Qwen's XML tool format has ambiguous boundary whitespace for string values.
// A JSON object retains literal newlines/spaces without trimming user content.
export function literalTool(tool){
 return {...tool,
  description:tool.description+' Pass the original fields inside the input object, preserving exact text and whitespace.',
  parameters:{type:'object',properties:{input:tool.parameters},required:['input'],additionalProperties:false},
  execute:async(id,args,...rest)=>{
   if(!args?.input||typeof args.input!=='object'||Array.isArray(args.input))throw Error('Structured input is required');
   return tool.execute(id,args.input,...rest);
  }
 };
}
